<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(asset('admin_assets/dist/js/js_pages/subscribers.js')); ?>"></script>

    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-5 align-self-center">
                    <h4 class="page-title">Subscribers</h4>
                </div>

            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
            <!-- ============================================================== -->
            <!-- Start Page Content -->
            <!-- ============================================================== -->
            <div class="row">
                <div class="col-12">
                    <div class="card p-4">

                        <div>
                            <button type="button" class="edit float-right" data-toggle="modal" data-target="#exampleModal_3"  ><i class="fa fa-list p_edit" aria-hidden="true" style="font-size:24px"></i></button>
                        </div>

                        <form action="<?php echo e(route('subscribers.email')); ?>" method="post" id="subscribers_email_send">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputTo">To</label>
                                <input  type="text" class="form-control" id="exampleInputTo" value="All Subscribers" readonly="readonly" >
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Subject<?php echo $errors->has('subject') ? '<div style="color:red;    display: inline;" >*</div>' : '';?></label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Subject" name="subject" >
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlTextarea">Message<?php echo $errors->has('message') ? '<div style="color:red;    display: inline;" >*</div>' : '';?></label>
                                <textarea class="form-control rounded-0" id="exampleFormControlTextarea" rows="5" placeholder="Enter Message" name="message" ></textarea>
                            </div>

                            <div class="float-right">
                                <button type="submit" class="btn btn-primary float-right">Send Messages</button>
                                <img id="loading" src="<?php echo e(asset('images/loading.gif')); ?>" width="40px" height="40px" alt="please wait" style="display: none">
                            </div>

                        </form>
                        <?php echo $__env->make('admin.layouts.modal_subscribers_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




























                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Right sidebar -->
    <!-- ============================================================== -->
    <!-- .right-sidebar -->
    <!-- ============================================================== -->
    <!-- End Right sidebar -->
    <!-- ============================================================== -->
    </div>

    <?php echo $__env->make('admin.layouts.modal_add_portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.layouts.modal_edit_portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog_laravel\blog\resources\views/admin/subscribers.blade.php ENDPATH**/ ?>