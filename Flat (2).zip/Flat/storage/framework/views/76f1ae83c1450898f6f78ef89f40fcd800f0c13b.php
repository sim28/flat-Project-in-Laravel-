<h3> Hello dear friend</h3>

<a href="<?php echo e(route('subscribe.verification') . '?token=' .$token); ?>">click for subcribing</a><?php /**PATH C:\xampp\htdocs\Flat\resources\views/admin/mail_views/Subscribers_first_mail.blade.php ENDPATH**/ ?>