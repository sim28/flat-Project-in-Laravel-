            <footer class="footer text-center">
                All Rights Reserved by Nice admin. Designed and Developed by
                <a href="https://wrappixel.com">WrapPixel</a>.
            </footer><?php /**PATH C:\xampp\htdocs\Flat\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>