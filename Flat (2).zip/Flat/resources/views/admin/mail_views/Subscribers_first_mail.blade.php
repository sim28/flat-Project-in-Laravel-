<h3> Hello dear friend</h3>

<a href="{{route('subscribe.verification') . '?token=' .$token}}">click for subcribing</a>