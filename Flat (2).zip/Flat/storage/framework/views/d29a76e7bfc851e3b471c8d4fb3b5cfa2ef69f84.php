        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('portfolio.index')); ?>" aria-expanded="false">

                                <span class="hide-menu">Portfolio</span>
                            </a>
                        </li>
                        
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('contacts.index')); ?>" aria-expanded="false">

                                <span class="hide-menu">Contacts</span>
                            </a>
                        </li>

                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('subscribers')); ?>" aria-expanded="false">

                                <span class="hide-menu">Subscribers</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('testimonials.index')); ?>" aria-expanded="false">

                                <span class="hide-menu">Testimonials</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside><?php /**PATH C:\xampp\htdocs\blog_laravel\blog\resources\views/admin/layouts/aside.blade.php ENDPATH**/ ?>