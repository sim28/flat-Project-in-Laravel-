<h3> Hello dear Subscriber</h3>

<p><?php echo e($data['message']); ?></p>
<?php /**PATH C:\xampp\htdocs\blog_laravel\blog\resources\views/admin/mail_views/Subscribers_regular_mail.blade.php ENDPATH**/ ?>