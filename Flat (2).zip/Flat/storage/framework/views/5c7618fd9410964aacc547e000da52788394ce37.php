<title>Flat</title>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/fav-icon.png')); ?>" />
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/theme-style.css" rel='stylesheet' type='text/css' />
<script src="js/jquery.easing.min.js"></script>

<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<!----webfonts---->
<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,300,500,700,800,900,600,200' rel='stylesheet' type='text/css'>
    <!----//webfonts---->
    <!----requred-js-files---->
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<!----//requred-js-files---->
<script type="text/javascript" 	src="<?php echo e(asset('js/jquery.smint.js')); ?>"></script>

<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/additional-methods.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<script type="text/javascript">
    $(document).ready( function() {
        $('.subMenu').smint({
            'scrollSpeed' : 1000
        });
    });
</script>
<style type="text/css">
    .error{
        border-color: red;
    }
    .sub:hover{
        transition: 0.5s;
        background-color: rgb(231, 76, 60);
    }

    #name-error P{
        font-size: 14px;
    }
</style><?php /**PATH C:\xampp\htdocs\Flat\resources\views/layouts/head.blade.php ENDPATH**/ ?>