<!-- Modal -->
<div class="modal fade" id="testimonial_show" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Testimonial</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <p id="testimonial_text"></p>

    </div>
  </div>
</div>
</div><?php /**PATH C:\xampp\htdocs\Flat\resources\views/admin/layouts/modal_testimonial_show.blade.php ENDPATH**/ ?>