<h3> Hello dear Subscriber</h3>

<p>{{$data['message']}}</p>
