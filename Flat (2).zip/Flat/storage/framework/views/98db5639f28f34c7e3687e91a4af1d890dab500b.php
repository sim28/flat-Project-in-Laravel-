<p><?php echo e($data['message']); ?></p>
<?php /**PATH C:\xampp\htdocs\Flat\resources\views/admin/mail_views/Contact_answer_mail.blade.php ENDPATH**/ ?>